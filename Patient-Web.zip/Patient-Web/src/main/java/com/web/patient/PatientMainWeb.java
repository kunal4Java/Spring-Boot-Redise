package com.web.patient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientMainWeb {

    public static void main(String[] args) {
        SpringApplication.run(PatientMainWeb.class, args);
    }

}
