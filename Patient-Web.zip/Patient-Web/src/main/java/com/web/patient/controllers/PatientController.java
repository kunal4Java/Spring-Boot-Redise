package com.web.patient.controllers;

import com.web.patient.models.Patient;
import com.web.patient.services.PatientService;

import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "/ext/")
@RequiredArgsConstructor
public class PatientController {
	
	@Autowired
    private final PatientService patientService;

    @PostMapping(value = "/patient")
    public ResponseEntity<Patient> addPatient(@RequestBody Patient newPatient) {
        Patient patient = patientService.save(newPatient);
        return new ResponseEntity<>(patient, HttpStatus.CREATED);
    }

    @GetMapping(value = "/patient/{id}")
    public ResponseEntity<?> getPatient(@PathVariable("id") String id) {
        Patient patient = patientService.getPatientById(Long.parseLong(id));
        if (patient != null) {
            return new ResponseEntity<>(patient, HttpStatus.OK);
        }
        return new ResponseEntity<>("Patient not found", HttpStatus.OK);
    }

    @GetMapping(value = "/patient")
    public ResponseEntity<List<Patient>> getAllPatient() {
        List<Patient> patientDetails = patientService.getAllPatient();
        return ResponseEntity.ok(patientDetails);
    }

    @PutMapping(value = "/patient/{id}")
    public ResponseEntity<?> updatePatient(@PathVariable("id") String id, @RequestBody Patient patient) {
        Patient patientDetails = patientService.getPatientById(Long.parseLong(id));
        if (patientDetails != null) {
            patientDetails.setVisit_Type(patient.getVisit_Type());
            patientDetails.setPatient_name(patient.getPatient_name());
            patientDetails.setContact_no(patient.getContact_no());

            Patient returnedPatient = patientService.save(patientDetails);
            return new ResponseEntity<>(returnedPatient, HttpStatus.OK);
        }
        return new ResponseEntity<>("Patient not found", HttpStatus.OK);
    }

    @DeleteMapping(value = "/patient/{id}")
    public ResponseEntity<String> deletePatient(@PathVariable("id") String id) {
        Patient savedPatient = patientService.getPatientById(Long.parseLong(id));
        if (savedPatient != null) {
            patientService.deletePatientById(Long.parseLong(id));
            return new ResponseEntity<>("Patient deleted", HttpStatus.OK);
        }
        return new ResponseEntity<>("Patient not found", HttpStatus.OK);
    }

    @DeleteMapping(value = "/patient")
    public ResponseEntity<String> deleteAll() {
        patientService.deleteAllPatient();
        return new ResponseEntity<>("All patient are deleted", HttpStatus.OK);
    }

    @GetMapping(value = "/patient/{id}/readonly")
    public ResponseEntity<?> getPatientReadonly(@PathVariable("id") String id) {
        Patient patient = patientService.getPatientReadOnlyById(Long.parseLong(id));
        if (patient != null) {
            return new ResponseEntity<>(patient, HttpStatus.OK);
        }
        return new ResponseEntity<>("Patient not found", HttpStatus.OK);
    }
}
