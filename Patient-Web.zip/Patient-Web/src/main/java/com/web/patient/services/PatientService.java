package com.web.patient.services;

import com.web.patient.PatientCacheData;
import com.web.patient.models.Patient;
import com.web.patient.repositories.PatientRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PatientService {

	private final Log log = LogFactory.getLog(getClass());
    @Autowired
	private final PatientRepository patientRepository;

    @CachePut(value = "PATIENT", key = "'PATIENTNO:' + #patient.id")
    public Patient save(Patient patient) {
        log.info("Patient details"+patient);
        return patientRepository.save(patient);
    }

    @Cacheable(value = "PATIENT", key = "'PATIENTNO:' + #id")
    public Patient getPatientById(Long id) {
        log.info("Searching in database" + id);
        return patientRepository.findById(id).orElse(null);
    }

    @PatientCacheData(value = "PATIENT", key = "'PATIENTNO:' + #id")
    public Patient getPatientReadOnlyById(long id) {
    	 log.info("Searching in database" + id);
        return patientRepository.findById(id).orElse(null);
    }

    public List<Patient> getAllPatient() {
        return patientRepository.findAll();
    }

    @CacheEvict(value = "PATIENT", key = "'PATIENTNO:' + #id")
    public void deletePatientById(Long id) {
        patientRepository.deleteById(id);
        log.info("Patient Id"+ id);
    }

    @CacheEvict(value = "PATIENT", allEntries = true)
    public void deleteAllPatient() {
        patientRepository.deleteAll();
        log.info("Clearing entire cache");
    }
}
