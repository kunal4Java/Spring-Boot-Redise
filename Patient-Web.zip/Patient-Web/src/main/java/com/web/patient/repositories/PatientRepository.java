package com.web.patient.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.web.patient.models.Patient;

public interface PatientRepository extends JpaRepository<Patient, Long> {
}
